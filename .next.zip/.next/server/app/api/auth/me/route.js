var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/me/route.js")
R.c("server/chunks/[root-of-the-server]__0de1cy6._.js")
R.c("server/chunks/[root-of-the-server]__1ky85o7._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_me_route_actions_17uv6xh.js")
R.m(93025)
module.exports=R.m(93025).exports
