var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/collections/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__05tbdvv._.js")
R.c("server/chunks/[root-of-the-server]__1ky85o7._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_collections_[id]_route_actions_07rwuhb.js")
R.m(26953)
module.exports=R.m(26953).exports
