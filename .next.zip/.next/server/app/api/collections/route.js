var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/collections/route.js")
R.c("server/chunks/[root-of-the-server]__0to_2f6._.js")
R.c("server/chunks/[root-of-the-server]__1ky85o7._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_collections_route_actions_1vo_ju0.js")
R.m(95607)
module.exports=R.m(95607).exports
