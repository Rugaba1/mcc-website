var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/testimonials/route.js")
R.c("server/chunks/[root-of-the-server]__1w1ca7o._.js")
R.c("server/chunks/[root-of-the-server]__1ky85o7._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_testimonials_route_actions_0e8eko-.js")
R.m(84438)
module.exports=R.m(84438).exports
