var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/testimonials/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__06llry0._.js")
R.c("server/chunks/[root-of-the-server]__1ky85o7._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_testimonials_[id]_route_actions_1dis-28.js")
R.m(19829)
module.exports=R.m(19829).exports
