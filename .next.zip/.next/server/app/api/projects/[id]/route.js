var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/projects/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1j16ddh._.js")
R.c("server/chunks/[root-of-the-server]__1ky85o7._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_projects_[id]_route_actions_0xth066.js")
R.m(70457)
module.exports=R.m(70457).exports
