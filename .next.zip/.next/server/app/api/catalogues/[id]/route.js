var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/catalogues/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1bujf3m._.js")
R.c("server/chunks/[root-of-the-server]__1ky85o7._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_catalogues_[id]_route_actions_0rxjw16.js")
R.m(69982)
module.exports=R.m(69982).exports
