var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/catalogues/route.js")
R.c("server/chunks/[root-of-the-server]__0imwdh9._.js")
R.c("server/chunks/[root-of-the-server]__1ky85o7._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_catalogues_route_actions_1ml0bd3.js")
R.m(28085)
module.exports=R.m(28085).exports
