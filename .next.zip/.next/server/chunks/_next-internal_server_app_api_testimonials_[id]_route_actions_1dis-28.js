module.exports=[51939,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_testimonials_%5Bid%5D_route_actions_1dis-28.js.map