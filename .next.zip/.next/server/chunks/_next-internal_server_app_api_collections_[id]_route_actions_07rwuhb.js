module.exports=[36628,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_collections_%5Bid%5D_route_actions_07rwuhb.js.map