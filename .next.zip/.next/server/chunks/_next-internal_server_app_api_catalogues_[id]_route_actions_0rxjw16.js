module.exports=[31084,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_catalogues_%5Bid%5D_route_actions_0rxjw16.js.map