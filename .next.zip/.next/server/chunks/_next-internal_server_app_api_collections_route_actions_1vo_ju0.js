module.exports=[14186,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_collections_route_actions_1vo_ju0.js.map