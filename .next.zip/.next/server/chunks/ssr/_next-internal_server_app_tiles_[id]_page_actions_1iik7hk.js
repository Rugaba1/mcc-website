module.exports=[83727,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_tiles_%5Bid%5D_page_actions_1iik7hk.js.map