module.exports=[26658,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_catalogues_route_actions_1ml0bd3.js.map